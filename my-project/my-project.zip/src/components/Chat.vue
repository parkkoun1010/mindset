<template>
  <div class="main_box">
    <div>
      Chat
    </div>
  </div>
</template>
<script>
export default {
  name: "Chat"
};
</script>
