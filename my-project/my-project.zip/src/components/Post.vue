<template>
  <div class="main_box">
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: "Post"
};
</script>
<style src="@/assets/css/style.css"></style>
