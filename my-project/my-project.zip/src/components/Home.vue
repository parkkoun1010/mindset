<template>
  <div class="main_box">
    <div class="box_inside">
      <div class="box_small">
        <h1>오늘의 한마디</h1>
        <p class="text">
          오늘 하루도 힘내세요! 마음가짐은 늘 여러분과 함께합니다.
        </p>
        <img id="calli" src="@/assets/img/calligraphy.png" />
      </div>
      <div class="box_small">
        <h1>마음가짐이란?</h1>
        <p class="text">
          오늘 하루도 힘내세요! 마음가짐은 늘 여러분과 함께합니다.오늘 하루도
          힘내세요! 마음가짐은 늘 여러분과 함께합니다.오늘 하루도 힘내세요!
          마음가짐은 늘 여러분과 함께합니다.오늘 하루도 힘내세요! 마음가짐은 늘
          여러분과 함께합니다.오늘 하루도 힘내세요! 마음가짐은 늘 여러분과
          함께합니다.오늘 하루도 힘내세요! 마음가짐은 늘 여러분과
          함께합니다.오늘 하루도 힘내세요! 마음가짐은 늘 여러분과 함께합니다.
          오늘 하루도 힘내세요! 마음가짐은 늘 여러분과 함께합니다.오늘 하루도
          힘내세요! 마음가짐은 늘 여러분과 함께합니다.
        </p>
      </div>
      <div class="blank_bottom"></div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Home"
};
</script>
<style src="@/assets/css/style.css"></style>
